package com.Biblioteca.Biblioteca.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.Biblioteca.Biblioteca.model.CatLibro;
import com.Biblioteca.Biblioteca.service.CatLibroService;

@RestController
@RequestMapping("/api/v1/Categoria_libros")
public class CatLibroController {

    @Autowired
    private CatLibroService catLibroService;

    @GetMapping
    public ResponseEntity<List<CatLibro>> listar(){
        List<CatLibro> listaCatLibro = catLibroService.findAll();
        if(listaCatLibro.isEmpty()){
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.ok(listaCatLibro);
    }

    @PostMapping
    public ResponseEntity<CatLibro> guardar(@RequestBody CatLibro catLibro){
        CatLibro NuevaCatLibro = catLibroService.save(catLibro);
        return ResponseEntity.status(HttpStatus.CREATED).body(NuevaCatLibro);
    }

    @GetMapping("/{id}")
    public ResponseEntity<CatLibro> buscar(@PathVariable Long id){
        try{
            CatLibro catLibro = catLibroService.findById(id);
            return ResponseEntity.ok(catLibro);
        }catch (Exception e){
            return ResponseEntity.notFound().build();
        }
    }

    @PutMapping("/{}")
    public ResponseEntity<CatLibro> actualizar(@PathVariable Long id, @RequestBody CatLibro catLibro){
        try{
            catLibroService.save(catLibro);
            return ResponseEntity.ok(catLibro);
        }catch( Exception e){
            return ResponseEntity.notFound().build();
        }
    }

    @PatchMapping("/{id}")
    public ResponseEntity<CatLibro> patchCatLibro(@PathVariable Long id, @RequestBody CatLibro partialCatLibro) {
        try {
            CatLibro actualizarCatLibro = catLibroService.patchCatLibro(id, partialCatLibro);
            return ResponseEntity.ok(actualizarCatLibro);
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> eliminar(@PathVariable Long id){
        try{
            catLibroService.delete(id);
            return ResponseEntity.noContent().build();
        }catch (Exception e){
            return ResponseEntity.notFound().build();
        }
    }
}
