package com.Biblioteca.Biblioteca.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.Biblioteca.Biblioteca.model.TipoUsuario;
import com.Biblioteca.Biblioteca.service.TipoUsuarioService;

@RestController
@RequestMapping("/api/v1/TipUsuario")
public class TipoUsuarioController {

    @Autowired
    private TipoUsuarioService tipoUsuarioService;

    @GetMapping
    public ResponseEntity<List<TipoUsuario>> listar(){
        List<TipoUsuario> listaTipoUsuario = tipoUsuarioService.findAll();
        if(listaTipoUsuario.isEmpty()){
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.ok(listaTipoUsuario);
    }

    
}
