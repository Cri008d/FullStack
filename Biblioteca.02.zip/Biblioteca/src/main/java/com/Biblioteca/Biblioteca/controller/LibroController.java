package com.Biblioteca.Biblioteca.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.Biblioteca.Biblioteca.model.Libro;
import com.Biblioteca.Biblioteca.service.LibroService;

@RestController
@RequestMapping("/api/v1/Libros")
public class LibroController {

    @Autowired
    private LibroService libroService;

    @GetMapping
    public ResponseEntity<List<Libro>> listar(){
        List<Libro> listaLibros = libroService.findAll();
        if(listaLibros.isEmpty()){
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.ok(listaLibros);
    }

    @PostMapping
    public ResponseEntity<Libro> guardar(@RequestBody Libro libro){
        Libro libroNuevo = libroService.save(libro);
        return ResponseEntity.status(HttpStatus.CREATED).body(libroNuevo);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Libro> buscar(@PathVariable Long id){
        try{
            Libro libro = libroService.findById(id);
            return ResponseEntity.ok(libro);
        }catch (Exception e){
            return ResponseEntity.notFound().build();
        }
    }

    @PutMapping("/{id}")
    public ResponseEntity<Libro> actualizar(@PathVariable Long id, @RequestBody Libro libro){
        try{
            libroService.save(libro);
            return ResponseEntity.ok(libro);
        }catch( Exception e){
            return ResponseEntity.notFound().build();
        }
    }

    @PatchMapping("/{id}")
    public ResponseEntity<Libro> patchLibro(@PathVariable Long id, @RequestBody Libro partialLibro) {
        try {
            Libro actualizarLibro = libroService.patchLibro(id, partialLibro);
            return ResponseEntity.ok(actualizarLibro);
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> eliminar(@PathVariable Long id){
        try{
            libroService.delete(id);
            return ResponseEntity.noContent().build();
        }catch (Exception e){
            return ResponseEntity.notFound().build();
        }
    }
}
