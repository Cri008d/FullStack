package com.Biblioteca.Biblioteca.model;

import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name="Libros")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Libro {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(nullable = false)
    private String titulo;

    @Column(nullable = false, length = 50)
    private String autor;

    @Column(nullable = false, length = 50)
    private String editorial;

    @Column(nullable = false, length = 13)
    private Integer isbn;

    @Column(nullable = false)
    private String descripcion;

    @Column(nullable = false)
    private Date fechaPublicacion;

    @Column(nullable = false)
    private int precio;

    @Column(nullable = false, length = 3)
    private int stock;

    @ManyToOne
    @JoinColumn(name = "categoria_libro", nullable = false)
    private CatLibro catLibro;
}
