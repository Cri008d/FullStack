package biblioteca.salas.duoc.biblioteca.salas.duoc.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import biblioteca.salas.duoc.biblioteca.salas.duoc.model.Reserva;

public interface ReservaRepository extends JpaRepository<Reserva, Long>{

}
