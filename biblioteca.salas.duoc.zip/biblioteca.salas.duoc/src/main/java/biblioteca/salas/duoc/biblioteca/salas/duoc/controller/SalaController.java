package biblioteca.salas.duoc.biblioteca.salas.duoc.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import biblioteca.salas.duoc.biblioteca.salas.duoc.service.SalaService;
import biblioteca.salas.duoc.biblioteca.salas.duoc.model.Sala;
import java.util.List;

@Repository
@RequestMapping("/api/v1/salas")
public class SalaController {

    @Autowired
    private SalaService salaService;

    @GetMapping
    public ResponseEntity<List<Sala>> getAllSalas() {
        List<Sala> salas = salaService.findAll();
        if (salas.isEmpty()) {
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.ok(salas);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Sala> getSalaById(Long id) {
        Sala sala = salaService.findById(id);
        if (sala == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(sala);
    }

    @PostMapping
    public ResponseEntity<Sala> createSala(Sala sala) {
        Sala createdSala = salaService.save(sala);
        return ResponseEntity.status(201).body(createdSala);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Sala> updateSala(Sala sala) {
        Sala updatedSala = salaService.save(sala);
        if (updatedSala == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(updatedSala);
    }

    @PatchMapping("/{id}")
    public ResponseEntity<Sala> patchSala(Long id, Sala sala) {
        Sala patchedSala = salaService.patchSala(id, sala);
        if (patchedSala == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(patchedSala);
    }
    
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteSala(Long id) {
        if (salaService.findById(id) == null) {
            return ResponseEntity.notFound().build();
        }
        salaService.deleteById(id);
        return ResponseEntity.noContent().build();  
    }
    
}
