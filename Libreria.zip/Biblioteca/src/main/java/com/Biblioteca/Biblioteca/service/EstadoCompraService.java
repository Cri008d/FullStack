package com.Biblioteca.Biblioteca.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Biblioteca.Biblioteca.model.EstadoCompra;
import com.Biblioteca.Biblioteca.repository.EstadoCompraRepository;

import jakarta.transaction.Transactional;

@Service
@Transactional
public class EstadoCompraService {

    @Autowired
    private EstadoCompraRepository estadoCompraRepository;

    public List<EstadoCompra> findAll(){
        return estadoCompraRepository.findAll();
    }

    public EstadoCompra findById(Long id){
        return estadoCompraRepository.findById(id).get();
    }

    public EstadoCompra save(EstadoCompra estadoCompra){
        return estadoCompraRepository.save(estadoCompra);
    }

    public void delete(Long id){
        estadoCompraRepository.deleteById(id);
    }

    public EstadoCompra patchEstadoCompra(Long id, EstadoCompra partialEstadoCompra){
        Optional<EstadoCompra> EstadoCompraOptional = estadoCompraRepository.findById(id);
        if (EstadoCompraOptional.isPresent()) {
            
            EstadoCompra EstadoCompraToUpdate = EstadoCompraOptional.get();
            
            if (partialEstadoCompra.getDescEstado() != null) {
                EstadoCompraToUpdate.setDescEstado(partialEstadoCompra.getDescEstado());
            }
            return estadoCompraRepository.save(EstadoCompraToUpdate);
        } else {
            return null;
        }
    }
}
