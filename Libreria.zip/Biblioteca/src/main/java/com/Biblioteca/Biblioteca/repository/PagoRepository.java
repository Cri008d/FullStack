package com.Biblioteca.Biblioteca.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.Biblioteca.Biblioteca.model.Pago;

@Repository
public interface PagoRepository extends JpaRepository<Pago, Long>{

}
