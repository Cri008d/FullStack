package com.Biblioteca.Biblioteca.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Biblioteca.Biblioteca.model.Pago;
import com.Biblioteca.Biblioteca.repository.PagoRepository;

import jakarta.transaction.Transactional;

@Service
@Transactional
public class PagoService {

    @Autowired
    private PagoRepository pagoRepository;

    public List<Pago> findAll(){
        return pagoRepository.findAll();
    }

    public Pago findById(Long id){
        return pagoRepository.findById(id).get();
    }

    public Pago save(Pago pago){
        return pagoRepository.save(pago);
    }

    public void delete(Long id){
        pagoRepository.deleteById(id);
    }

    public Pago patchPago(Long id, Pago partialPago){
        Optional<Pago> PagoOptional = pagoRepository.findById(id);
        if (PagoOptional.isPresent()) {
            
            Pago PagoToUpdate = PagoOptional.get();
            
            if (partialPago.getPago() != null) {
                PagoToUpdate.setPago(partialPago.getPago());
            }
            return pagoRepository.save(PagoToUpdate);
        } else {
            return null;
        }
    }
}
