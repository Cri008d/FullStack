package com.Biblioteca.Biblioteca.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.Biblioteca.Biblioteca.model.CatLibro;

@Repository
public interface CatLibroRepository extends JpaRepository<CatLibro, Long>{

}
