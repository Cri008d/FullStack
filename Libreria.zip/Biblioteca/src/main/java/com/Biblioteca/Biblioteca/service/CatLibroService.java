package com.Biblioteca.Biblioteca.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Biblioteca.Biblioteca.model.CatLibro;
import com.Biblioteca.Biblioteca.repository.CatLibroRepository;

import jakarta.transaction.Transactional;

@Service
@Transactional
public class CatLibroService {

    @Autowired
    private CatLibroRepository catLibroRepository;

    public List<CatLibro> findAll(){
        return catLibroRepository.findAll();
    }

    public CatLibro findById(Long id){
        return catLibroRepository.findById(id).get();
    }

    public CatLibro save(CatLibro catLibro){
        return catLibroRepository.save(catLibro);
    }

    public void delete(Long id){
        catLibroRepository.deleteById(id);
    }

    public CatLibro patchCatLibro(Long id, CatLibro partialCatLibro){
        Optional<CatLibro> catLibroOptional = catLibroRepository.findById(id);
        if (catLibroOptional.isPresent()) {
            
            CatLibro catLibroToUpdate = catLibroOptional.get();
            
            if (partialCatLibro.getCategoria() != null) {
                catLibroToUpdate.setCategoria(partialCatLibro.getCategoria());
            }
            return catLibroRepository.save(catLibroToUpdate);
        } else {
            return null;
        }
    }
}