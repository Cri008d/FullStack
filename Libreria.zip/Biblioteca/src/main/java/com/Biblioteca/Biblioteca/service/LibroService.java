package com.Biblioteca.Biblioteca.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Biblioteca.Biblioteca.model.Libro;
import com.Biblioteca.Biblioteca.repository.LibroRepository;

import jakarta.transaction.Transactional;

@Service
@Transactional
public class LibroService {

    @Autowired
    private LibroRepository libroRepository;

    public List<Libro> findAll(){
        return libroRepository.findAll();
    }

    public Libro findById(Long id){
        return libroRepository.findById(id).get();
    }

    public Libro save(Libro libro){
        return libroRepository.save(libro);
    }

    public void delete(Long id){
        libroRepository.deleteById(id);
    }

    public Libro patchLibro(Long id, Libro parcialLibro){
        Optional<Libro> LibroOptional = libroRepository.findById(id);
        if (LibroOptional.isPresent()) {
            
            Libro LibroToUpdate = LibroOptional.get();
            
            if (parcialLibro.getTitulo() != null) {
                LibroToUpdate.setTitulo(parcialLibro.getTitulo());
            }

            if(parcialLibro.getAutor() != null){
                LibroToUpdate.setAutor(parcialLibro.getAutor());
            }

            if(parcialLibro.getEditorial() != null){
                LibroToUpdate.setEditorial(parcialLibro.getEditorial());
            }

            if(parcialLibro.getIsbn() != null){
                LibroToUpdate.setIsbn(parcialLibro.getIsbn());
            }

            if(parcialLibro.getDescripcion() != null){
                LibroToUpdate.setDescripcion(parcialLibro.getDescripcion());
            }

            if(parcialLibro.getFechaPublicacion() != null){
                LibroToUpdate.setFechaPublicacion(parcialLibro.getFechaPublicacion());
            }

            if(parcialLibro.getPrecio() != 0) {
                LibroToUpdate.setPrecio(parcialLibro.getPrecio());
            }

            if(parcialLibro.getStock() != 0) {
                LibroToUpdate.setStock(parcialLibro.getStock());
            }
            return libroRepository.save(LibroToUpdate);
        } else {
            return null;
        }
    }
}
