package com.Biblioteca.Biblioteca.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.Biblioteca.Biblioteca.model.EstadoCompra;

@Repository
public interface EstadoCompraRepository extends JpaRepository<EstadoCompra, Long>{


}
