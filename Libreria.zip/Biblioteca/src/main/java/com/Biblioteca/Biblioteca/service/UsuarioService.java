package com.Biblioteca.Biblioteca.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Biblioteca.Biblioteca.model.Usuario;
import com.Biblioteca.Biblioteca.repository.UsuarioRepository;

import jakarta.transaction.Transactional;

@Service
@Transactional
public class UsuarioService {

    @Autowired
    private UsuarioRepository usuarioRepository;

    public List<Usuario> findAll(){
        return usuarioRepository.findAll();
    }

    public Usuario findById(Long id){
        return usuarioRepository.findById(id).get();
    }

    public Usuario save(Usuario usuario){
        return usuarioRepository.save(usuario);
    }

    public void delete(Long id){
        usuarioRepository.deleteById(id);
    }

    public Usuario patchUsuario(Long id, Usuario partialUsuario){
        Optional<Usuario> usuarioOptional = usuarioRepository.findById(id);
        if(usuarioOptional.isPresent()){

            Usuario usuarioToUpdate = usuarioOptional.get();

            if(partialUsuario.getNombre() != null){
                usuarioToUpdate.setNombre(partialUsuario.getNombre());
            }

            if(partialUsuario.getApellido() != null){
                usuarioToUpdate.setApellido(partialUsuario.getApellido());
            }

            if(partialUsuario.getCorreo() != null){
                usuarioToUpdate.setCorreo(partialUsuario.getCorreo());
            }

            if(partialUsuario.getContraseña() != null){
                usuarioToUpdate.setContraseña(partialUsuario.getContraseña());
            }

            if(partialUsuario.getDireccion() != null){
                usuarioToUpdate.setDireccion(partialUsuario.getDireccion());
            }

            if(partialUsuario.getNumeroTelefono() != null){
                usuarioToUpdate.setNumeroTelefono(partialUsuario.getNumeroTelefono());
            }
            return usuarioRepository.save(usuarioToUpdate);
            
        }else{
            return null;
        }
    }
}